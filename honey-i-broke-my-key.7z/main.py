"""
HONEY, I BROKE MY KEY!
              ~ WRITTEN BY @ATOMICNICOS
            FOR THE APPSEC VILLAGE@DC29
"""

import hashlib
from functools import reduce
from PIL import Image
from pixels import pixels
from verification import verification

PATH_NAME = "./password.png"

def verify(img, sha, *pos):
  img_colors = []
  for xy in pos:
    img_colors += [value(*img.getpixel(xy))]
  calc_sha = hashlib.sha256(str.encode(str(img_colors))).hexdigest()
  return sha == calc_sha, calc_sha

def value(*iter):
  if type(iter[0]) == int:
    return reduce(lambda x, y: x ^ y, iter)
  else:
    return value(*[value(*z) for z in iter])

if __name__ == '__main__':
  flag = ""
  img = Image.open(PATH_NAME, "r")
  for i in range(len(pixels)):
    values = []
    for j in range(len(pixels[i])):
      values += [img.getpixel(pixels[i][j])]
    flag += chr(value(*values))
  print(f'COMPUTED FLAG: "{ flag }"')
  
  print('\nIMAGE VERIFICATION STARTED\n')
  
  verified = True
  for sha, pos in verification.items():
    v = verify(img, sha, *pos)
    if not v[0]:
      verified = False
      print(f"VERIFICATION FAILED FOR PIXEL GROUP: {pos}\nEXPECTED: { sha } | ACTUAL: { v[1] }\n")
  
  if verified:
    print(f'IMAGE VERIFICATION SUCCESSFUL\n\nThe flag is "{ flag }"')

  img.close()
